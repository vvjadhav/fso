"""Test set for SockShop UI"""

from selenium.common.exceptions import (
    ElementNotVisibleException,
    # NoSuchElementException,
    TimeoutException
)

from load.driver.sockshop import SockShopDriver
from load.settings import TARGET_BASE_URL
from load.utils import (
    logger,
    wait
)
from load.useragent import UserAgent


iteration = 1
delay = 5
user_agent = UserAgent(limit=100)
# Print list of fake user agents
user_agent.print_user_agents()

while True:
    logger.info("Starting iteration #%d", iteration)

    user_agent_string = user_agent.random()
    logger.info("Using fake User-Agent: %s", user_agent_string)

    logger.info("Connect to Selenium Grid")
    store = SockShopDriver(TARGET_BASE_URL, user_agent=user_agent_string)

    try:
        store.goto_home()
        store.login("user1", "password")
        wait(delay)
        store.goto_catalogue()
        wait(delay)
        store.logout()
        wait(delay)

    except TimeoutException:
        logger.error("Timed out waiting for login page to load")
        store.close()
        continue
    except ElementNotVisibleException:
        logger.error("ElementNotVisibleException")
        store.close()
        continue
    except KeyboardInterrupt:
        logger.info("Close current window")
        store.close()
        break

    store.close()
    iteration += 1

    # elem.send_keys(Keys.RETURN)
    # assert "No results found." not in driver.page_source
    # print(driver.page_source)
    # elem.send_keys(Keys.RETURN)
    # assert "No results found." not in driver.page_source
    # driver.close()
