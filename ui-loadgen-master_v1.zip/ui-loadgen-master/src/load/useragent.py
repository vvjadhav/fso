"""Module to handle generation of random User-Agent strings"""

# credit Python Random User-Agent Generator <http://pastebin.com/zYPWHnc6#>
# User-Agent: Mozilla/5.0 (<system-information>) <platform> (<platform-details>) <extensions>

from random_user_agent.params import (OperatingSystem, SoftwareName)
from random_user_agent.user_agent import UserAgent as UA

# from load.utils import (random_choice, random_int_as_str)


class UserAgent:
    """Class to generate random user-agent strings"""

    def __init__(self, limit=100):
        software_names = [
            SoftwareName.CHROME.value,
            SoftwareName.FIREFOX.value,
            SoftwareName.SAFARI.value,
            SoftwareName.BRAVE.value,
            SoftwareName.EDGE.value
        ]
        operating_systems = [
            OperatingSystem.WINDOWS.value,
            OperatingSystem.LINUX.value,
            OperatingSystem.ANDROID.value,
            OperatingSystem.MACOS.value,
            OperatingSystem.MAC_OS_X.value,
            OperatingSystem.WINDOWS_MOBILE.value
        ]
        self.user_agent_rotator = UA(software_names=software_names, operating_systems=operating_systems, limit=limit)

    def random(self):
        """Get Random User Agent string"""
        return self.user_agent_rotator.get_random_user_agent()

    def get_user_agents(self):
        """Get list of user agents"""
        return self.user_agent_rotator.get_user_agents()

    def print_user_agents(self):
        """Print User-agent pool"""
        user_agent_pool = self.get_user_agents()
        print("Random User-agents pool size:", len(user_agent_pool), flush=True)
        print("Random User-agents pool:", flush=True)
        for user_agent in user_agent_pool:
            print(user_agent["user_agent"], flush=True)
        print()


# class UserAgentOld:
#     agent = {}
#
#     def random(self):
#         self.get_platform()
#         self.get_os()
#         self.get_browser()
#
#         if self.agent['browser'] == 'Chrome':
#             webkit = random_int_as_str(500, 599)
#             version = f"{random_int_as_str(0, 24)}.0{random_int_as_str(0, 1500)}.{random_int_as_str(0, 999)}"
#             return "Mozilla/5.0 (%s) AppleWebKit/%s.0 (KHTML, live Gecko) Chrome/%s Safari/%s" % (
#                 self.agent['os'], webkit, version, webkit)
#         elif self.agent['browser'] == 'Firefox':
#             year = random_int_as_str(2000, 2015)
#             month = random_int_as_str(1, 12).zfill(2)
#             day = random_int_as_str(1, 28).zfill(2)
#             gecko = "%s%s%s" % (year, month, day)
#             version = f"{random_int_as_str(1, 15)}.0"
#
#             return "Mozillia/5.0 (%s; rv:%s) Gecko/%s Firefox/%s" % (self.agent['os'], version, gecko, version)
#         elif self.agent['browser'] == 'IE':
#             version = f"{random_int_as_str(1, 10)}.0"
#             engine = f"{random_int_as_str(1, 5)}.0"
#             option = random_choice([True, False])
#             if option:
#                 token = "%s;" % (
#                     random_choice(['.NET CLR', 'SV1', 'Tablet PC', 'Win64; IA64', 'Win64; x64', 'WOW64'])
#                 )
#             else:
#                 token = ''
#
#             return "Mozilla/5.0 (compatible; MSIE %s; %s; %sTrident/%s)" % (version, self.agent['os'], token, engine)
#
#     def get_os(self):
#         if self.agent['platform'] == 'Machintosh':
#             self.agent['os'] = random_choice(['68K', 'PPC'])
#         elif self.agent['platform'] == 'Windows':
#             self.agent['os'] = random_choice(
#                 ['Win3.11', 'WinNT3.51', 'WinNT4.0', 'Windows NT 5.0', 'Windows NT 5.1', 'Windows NT 5.2',
#                  'Windows NT 6.0', 'Windows NT 6.1', 'Windows NT 6.2', 'Win95', 'Win98', 'Win 9x 4.90', 'WindowsCE'])
#         elif self.agent['platform'] == 'X11':
#             self.agent['os'] = random_choice(['Linux i686', 'Linux x86_64'])
#
#     def get_browser(self):
#         self.agent['browser'] = random_choice(['Chrome', 'Firefox', 'IE'])
#
#     def get_platform(self):
#         self.agent['platform'] = random_choice(['Machintosh', 'Windows', 'X11'])
