"""Settings for SockShop UI Load generator"""

from os import environ

# startPage = "http://10.0.110.131:30001/"
# hubUrl = "http://10.0.110.10:4444/wd/hub"
TARGET_BASE_URL = environ.get("TARGET_BASE_URL")
SELENIUM_HUB_URL = environ.get("SELENIUM_HUB_URL")
BROWSER_TYPE = environ.get("BROWSER")
USE_UPS = environ.get("USE_UPS", "False").lower() in ('true', '1', 'yes')
USE_PAYPAL = environ.get("USE_PAYPAL", "False").lower() in ('true', '1', 'yes')
PAYPAL_USERNAME = environ.get("PAYPAL_USERNAME")
PAYPAL_PASSWORD = environ.get("PAYPAL_PASSWORD")
PAYPAL_CREDS = {
    "username": PAYPAL_USERNAME,
    "password": PAYPAL_PASSWORD
}
SELENIUM_TOKEN = environ.get("SELENIUM_TOKEN")
