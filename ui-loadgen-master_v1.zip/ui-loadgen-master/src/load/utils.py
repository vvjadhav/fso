"""Utility function"""


import logging
from time import sleep
import secrets

LOG_FORMAT = '%(asctime)s - %(levelname)s - %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
logger = logging.getLogger('__name__')


def wait(wait_time):
    """Sleep for X number of seconds"""
    logger.info("Sleeping for %d seconds", wait_time)
    sleep(wait_time)


def random_int_as_str(start, stop):
    """
    Generates a random integer form provided range and return it as string
    :param start: An integer number specifying at which position to start
    :param stop: An integer number specifying at which position to stop
    :return: A string containing a random integer number
    """
    integer_num = secrets.choice(range(start, stop + 1))
    return str(integer_num)


def random_choice(choices):
    """
    Generates a random item from provided choices and return it as string
    :param choices: Iterable of choices
    :return: A string containing a random item from provided choices
    """
    item = secrets.choice(choices)
    return item
