"""Custom Selenium driver for SockShop demo app"""

from random import randint

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.remote_connection import ChromeRemoteConnection
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from load.settings import (
    BROWSER_TYPE,
    SELENIUM_HUB_URL,
    TARGET_BASE_URL,
    PAYPAL_CREDS,
    SELENIUM_TOKEN
)
from load.utils import logger, wait


class NopCommerceDriver:
    """Custom Selenium driver for NopCommerce demo app"""

    def __init__(self, base_url, default_wait_time=100, user_agent=None):
        self.base_url = base_url
        self.default_wait_time = default_wait_time
        self.driver = None
        self.user_agent = user_agent
        # self.user_agent = UserAgent(limit=50)
        # self.print_user_agent_pool()
        self._init_driver()
        self.driver.implicitly_wait(default_wait_time)

    def _init_driver(self):
        """Creates a Selenium remote WebDriver object"""

        # user_agent = self.user_agent.random()

        if BROWSER_TYPE == "chrome":
            chrome_options = ChromeOptions()
            chrome_options.add_argument('--no-sandbox')
            desired_capabilities = {
                'browserName': BROWSER_TYPE,
                'javascriptEnabled': True
            }
            if SELENIUM_TOKEN:
                logger.info("Configure Selenium Hub TOKEN")
                desired_capabilities['e34:auth'] = SELENIUM_TOKEN

            self.driver = webdriver.Remote(
                command_executor=ChromeRemoteConnection(SELENIUM_HUB_URL),
                desired_capabilities=desired_capabilities,
                options=chrome_options
            )
            cmd_args = {
                "cmd": "Network.setUserAgentOverride",
                "params": {
                    "userAgent": self.user_agent
                }
            }

            # https://github.com/SeleniumHQ/selenium/issues/7959
            self.driver.execute(
                driver_command="executeCdpCommand",
                params=cmd_args
            )

        elif BROWSER_TYPE == "firefox":
            firefox_options = FirefoxOptions()
            firefox_profile = FirefoxProfile()
            firefox_profile.set_preference("general.useragent.override", self.user_agent)
            firefox_options.profile = firefox_profile

            self.driver = webdriver.Remote(
                command_executor=SELENIUM_HUB_URL,
                desired_capabilities={'browserName': BROWSER_TYPE, 'javascriptEnabled': True},
                options=firefox_options
            )
            # print('Firefox:', self.driver.execute_script("return navigator.userAgent;"))
        else:
            self.driver = webdriver.Remote(
                command_executor=SELENIUM_HUB_URL,
                desired_capabilities={'browserName': BROWSER_TYPE, 'javascriptEnabled': True}
            )
        logger.info("Connected to Selenium Grid hub: %s, Browser type: %s, Session ID: %s", SELENIUM_HUB_URL, BROWSER_TYPE, self.driver.session_id)

    def goto_home(self, wait_time=None):
        """Loads home page"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading home page")
        self.driver.get(TARGET_BASE_URL)
        self.driver.maximize_window()
        logger.info("Loaded home page. Title: #%s", self.driver.title)

    def login(self, user, password, wait_time=None):
        """Login"""
        wait_time = wait_time or self.default_wait_time
        try:
            self.driver.implicitly_wait(5)
            self.driver.find_element_by_css_selector(".ico-logout")
            logger.warning("A user is already logged in")
            return
        except NoSuchElementException:
            self.driver.implicitly_wait(wait_time)
            logger.info("Open login page")
            self.driver.find_element_by_css_selector(".ico-login").click()
            timeout = 10

            # Wait until last element of the form (Log In button) is loaded
            element_present = EC.presence_of_element_located((By.CSS_SELECTOR, ".login-button"))
            WebDriverWait(self.driver, timeout).until(element_present)

            logger.info("Fill out login form")
            username = self.driver.find_element_by_id("Email")
            username.clear()
            username.click()
            username.send_keys(user)
            passwd = self.driver.find_element_by_id("Password")
            passwd.clear()
            passwd.click()
            passwd.send_keys(password)

            logger.info("Submit login form")
            self.driver.find_element_by_css_selector(".login-button").click()

    def logout(self, wait_time=None):
        """Logout"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        try:
            logger.info("Logout")
            self.driver.find_element_by_css_selector(".ico-logout").click()
        except NoSuchElementException:
            logger.warning("It seems that no user is logged in")

    def goto_electronics(self, wait_time=None):
        """Loads electronics page"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading Electronics page")
        elem = self.driver.find_element_by_link_text("Electronics")
        elem.click()

    def goto_cellphones(self, wait_time=None):
        """Loads electronics > cell phones page"""
        self.goto_electronics()
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading Cell Phones page")
        elem = self.driver.find_element_by_link_text("Cell phones")
        elem.click()

    def add_item_to_cart(self, item, wait_time=None):
        """Adds an item to the shopping cart"""
        item_name = item[0]
        item_button = item[1]
        quantity_field = item[2]
        desired_quantity = randint(1, 4)

        self.driver.implicitly_wait(5)
        # self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Adding %d '%s' item(s) to the cart", desired_quantity, item_name)
        # Find item and view item details
        logger.info("Open details page. Item name: %s", item_name)
        self.driver.find_element_by_link_text(item_name).click()
        # Update item quantity
        logger.info("Finding item quantity field and updating quantity")
        quantity = self.driver.find_element_by_id(quantity_field)
        quantity.clear()
        quantity.click()
        quantity.send_keys(desired_quantity)
        # Add item to the cart
        logger.info("Adding item to the cart")
        self.driver.find_element_by_id(item_button).click()

    def goto_cart(self, wait_time=None):
        """Loads Shopping Cart page"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading Shopping Cart page")
        elem = self.driver.find_element_by_css_selector('.cart-label')
        elem.click()

    def checkout(self, wait_time=None, use_ups=True, use_paypal=True):
        # shippingoption_0 = UPS 2nd Day Air
        # shippingoption_1 = Next Day Air

        shipping_option = "shippingoption_0" if use_ups else "shippingoption_1"

        """Checkout items in shopping cart"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading Shopping Cart page")
        self.driver.find_element_by_css_selector(".cart-label").click()
        wait(10)
        logger.info("Accept terms of service")
        self.driver.find_element_by_id("termsofservice").click()
        wait(8)
        logger.info("Click Checkout")
        self.driver.find_element_by_id("checkout").click()
        wait(8)
        logger.info("Accept default shipping address and click continue")
        self.driver.find_element_by_name("save").click()
        wait(8)
        logger.info("Select shipping method: %s", shipping_option)
        self.driver.find_element_by_id(shipping_option).click()
        logger.info("Click continue")
        self.driver.find_element_by_css_selector(".shipping-method-next-step-button").click()
        wait(8)
        logger.info("Accept default payment method and click continue")
        self.driver.find_element_by_css_selector(".payment-method-next-step-button").click()
        wait(10)

        if not use_paypal:
            logger.info("Confirm payment information and continue")
            self.driver.find_element_by_css_selector(".payment-info-next-step-button").click()
        else:
            self.pay_with_paypal()

        wait(8)
        logger.info("Place order")
        self.driver.find_element_by_css_selector(".confirm-order-next-step-button").click()

    def pay_with_paypal(self):
        """Make a payment using PayPal"""

        main_window = self.driver.window_handles[0]
        logger.info("Select Paypal iframe")
        paypal_iframe = self.driver.find_element_by_xpath("//iframe[@title='PayPal']")
        logger.info("Switching to Paypal iframe: %s", paypal_iframe)
        self.driver.switch_to.frame(paypal_iframe)
        logger.info("Select PayPal option")
        self.driver.find_element_by_xpath('/html/body/div/div/div[1]').click()
        paypal_window = self.driver.window_handles[1]
        wait(8)
        logger.info("Switching to Paypal pop-up window: %s, from window: %s", paypal_window, main_window)
        self.driver.switch_to.window(paypal_window)
        wait(8)
        logger.info("Click Log In button on PayPal pop-up window")
        self.driver.find_element_by_xpath('//button[text()="Log In"]').click()
        wait(8)
        logger.info("Fill out Paypal login email")
        username = self.driver.find_element_by_id("email")
        username.clear()
        username.click()
        username.send_keys(PAYPAL_CREDS["username"])
        logger.info("Click next on Paypal login form")
        self.driver.find_element_by_id("btnNext").click()
        wait(8)
        logger.info("Fill out Paypal login password")
        passwd = self.driver.find_element_by_id("password")
        passwd.clear()
        passwd.click()
        passwd.send_keys(PAYPAL_CREDS["password"])
        logger.info("Click Login on Paypal login form")
        self.driver.find_element_by_id("btnLogin").click()
        wait(8)
        logger.info("Click Complete Purchase on PayPal pop-up window")
        self.driver.find_element_by_id("payment-submit-btn").click()
        wait(8)
        logger.info("Switch to main window")
        self.driver.switch_to.window(main_window)

    def close(self):
        """Close current window"""
        logger.info("Close current window")
        self.driver.close()

    def quit(self):
        """Terminate the webdriver instance (all windows will close)"""
        logger.info("Close all windows and session")
        self.driver.quit()
