"""Custom Selenium driver for SockShop demo app"""


from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.remote_connection import ChromeRemoteConnection
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from load.settings import (BROWSER_TYPE, SELENIUM_HUB_URL, TARGET_BASE_URL)
from load.utils import logger


class SockShopDriver:
    """Custom Selenium driver for SockShop demo app"""

    def __init__(self, base_url, default_wait_time=100, user_agent=None):
        self.base_url = base_url
        self.default_wait_time = default_wait_time
        self.driver = None
        self.user_agent = user_agent
        # self.user_agent = UserAgent(limit=50)
        # self.print_user_agent_pool()
        self._init_driver()
        self.driver.implicitly_wait(default_wait_time)

    def _init_driver(self):
        """Creates a Selenium remote WebDriver object"""

        # user_agent = self.user_agent.random()

        if BROWSER_TYPE == "chrome":
            self.driver = webdriver.Remote(
                command_executor=ChromeRemoteConnection(SELENIUM_HUB_URL),
                desired_capabilities={'browserName': BROWSER_TYPE, 'javascriptEnabled': True}
            )
            cmd_args = {
                "cmd": "Network.setUserAgentOverride",
                "params": {
                    "userAgent": self.user_agent
                }
            }

            # https://github.com/SeleniumHQ/selenium/issues/7959
            self.driver.execute(
                driver_command="executeCdpCommand",
                params=cmd_args
            )

        elif BROWSER_TYPE == "firefox":
            firefox_options = Options()
            firefox_profile = FirefoxProfile()
            firefox_profile.set_preference("general.useragent.override", self.user_agent)
            firefox_options.profile = firefox_profile

            self.driver = webdriver.Remote(
                command_executor=SELENIUM_HUB_URL,
                desired_capabilities={'browserName': BROWSER_TYPE, 'javascriptEnabled': True},
                options=firefox_options
            )
            # print('Firefox:', self.driver.execute_script("return navigator.userAgent;"))
        else:
            self.driver = webdriver.Remote(
                command_executor=SELENIUM_HUB_URL,
                desired_capabilities={'browserName': BROWSER_TYPE, 'javascriptEnabled': True}
            )
        logger.info("Connected to Selenium Grid. Browser type: %s", BROWSER_TYPE)

    def login(self, user, password, wait_time=None):
        """Login"""
        try:
            self.driver.implicitly_wait(5)
            self.driver.find_element_by_id("logout-link")
            logger.warning("A user is already logged in")
            return
        except NoSuchElementException:
            self.driver.implicitly_wait(wait_time or self.default_wait_time)
            logger.info("Open login modal")
            self.driver.find_element_by_id("login-link").click()
            timeout = 10

            element_present = EC.presence_of_element_located((By.ID, "login-button"))
            WebDriverWait(self.driver, timeout).until(element_present)

            logger.info("Fill out login form")
            username = self.driver.find_element_by_id("username-modal")
            username.clear()
            username.click()
            username.send_keys(user)
            passwd = self.driver.find_element_by_id("password-modal")
            passwd.clear()
            passwd.click()
            passwd.send_keys(password)

            logger.info("Submit login form")
            self.driver.find_element_by_id("login-button").click()

    def logout(self, wait_time=None):
        """Logout"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        try:
            logger.info("Logout")
            self.driver.find_element_by_id("logout-link").click()
        except NoSuchElementException:
            logger.warning("It seems that no user is logged in")

    def goto_home(self, wait_time=None):
        """Loads home page"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading home page")
        self.driver.get(TARGET_BASE_URL)
        logger.info("Loaded home page. Title: #%s", self.driver.title)

    def goto_catalogue(self, wait_time=None):
        """Loads catalogue page"""
        self.driver.implicitly_wait(wait_time or self.default_wait_time)
        logger.info("Loading catalogue page")
        elem = self.driver.find_element_by_id("catalogue-link")
        elem.click()

    def close(self):
        """Close current window"""
        logger.info("Close current window")
        self.driver.close()
