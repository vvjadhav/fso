"""Test set for nopCommerce UI"""

from secrets import choice

from selenium.common.exceptions import (
    ElementNotVisibleException,
    NoSuchElementException,
    TimeoutException
)

from load.driver.nopcommerce import NopCommerceDriver
from load.settings import (
    TARGET_BASE_URL,
    USE_PAYPAL,
    USE_UPS,
    SELENIUM_HUB_URL
)
from load.utils import (
    logger,
    wait
)
from load.useragent import UserAgent


iteration = 0
delay = 6
user_agent = UserAgent(limit=100)
# Print list of fake user agents
user_agent.print_user_agents()
users = [
    ('james_pan@nopCommerce.com', '123456'),
    ('brenda_lindgren@nopCommerce.com', '123456'),
    ('arthur_holmes@nopCommerce.com', '123456'),
    ('steve_gates@nopCommerce.com', '123456'),
]

# Phones (name, addtocart-button-id, quantity-field-id)
phones = [
    ("Nokia Lumia 1020", "add-to-cart-button-20", "product_enteredQuantity_20"),
    ("HTC One Mini Blue", "add-to-cart-button-19", "product_enteredQuantity_19"),
    ("HTC One M8 Android L 5.0 Lollipop", "add-to-cart-button-18", "product_enteredQuantity_18")
]


while True:
    iteration += 1

    # Wait for a random number of seconds before next iteration
    if iteration > 1:
        wait(choice(range(5, 20)))

    logger.info("======= Starting iteration #%d", iteration)

    user_agent_string = user_agent.random()
    logger.info("Using fake User-Agent: %s", user_agent_string)
    logger.info("Target URL: %s", TARGET_BASE_URL)

    logger.info("Connect to Selenium Grid: %s", SELENIUM_HUB_URL)
    store = NopCommerceDriver(TARGET_BASE_URL, user_agent=user_agent_string)

    credentials = choice(users)
    username = credentials[0]
    password = credentials[1]
    logger.info("Random user: %s", username)

    item = choice(phones)

    try:
        store.goto_home()
        wait(delay)
        store.login(username, password)
        wait(delay)
        store.goto_cellphones()
        wait(delay + 3)
        store.add_item_to_cart(item, wait_time=10)
        wait(delay + 5)
        store.checkout(use_ups=USE_UPS, use_paypal=USE_PAYPAL)
        wait(delay)
        store.logout()
        wait(delay)

    except TimeoutException:
        logger.error("Timed out waiting for login page to load")
        store.quit()
        continue
    except ElementNotVisibleException:
        logger.error("ElementNotVisibleException")
        store.quit()
        continue
    except NoSuchElementException:
        logger.error("NoSuchElementException")
        store.quit()
        continue
    except KeyboardInterrupt:
        logger.info("Close current window")
        store.quit()
        break
    except Exception:
        logger.exception("There was an exception:", exc_info=True)
        store.quit()

    store.quit()
    logger.info("======= Completed iteration #%d", iteration)
