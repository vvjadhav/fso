# UI Load Generator

UI load generator written in Python that leverages Selenium Grid / Selenium Box to simulate users on the frontend of SockShop and nopCommerce demo applications. 


## Getting Started

### Installing & Running

Please, follow the instructions below to install and run the load generator in your **development** environment:

1. Fork this repository

2. Clone your forked repo: 

    ```bash
    git clone git@wwwin-github.cisco.com:<username>/ui-loadgen.git
    ```
    
3. Navigate into the new directory created by the `git clone` command: 

    ```bash
    cd ui-loadgen/src
    ```

4. Create a Python virtual environment and install the required packages:

    ```bash
    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
    ```

5. Set environment variables. E.g.:

    ```bash
    export SELENIUM_HUB_URL=http://10.0.110.131:30444/wd/hub
    export TARGET_BASE_URL=http://10.0.110.131:30001/
    export BROWSER=chrome
    export USE_PAYPAL=true
    export USE_UPS=true
    export PAYPAL_USERNAME=email@domain.com
    export PAYPAL_PASSWORD='my_secure_password'
    ```

    - `SELENIUM_HUB_URL`: The URL where your Selenium Grid hub is listening for new jobs
    - `BROWSER`: Requested browser type. Selenium Grid must have at least one node based on this type of browser. Some options are: firefox, chrome, operablink
    - `TARGET_BASE_URL`: Base URL for the website under test
    - `USE_PAYPAL`: Set it to True/true/1 if the nopCommerce app is integrated with PayPal for payments at checkout. Otherwise, set it to False/false/0, or don't set it. Default value is False.
    - `USE_UPS`: Set it to True/true/1 if the nopCommerce app is integrated with UPS for shipping. Otherwise, set it to False/false/0, or don't set it. Default value is False.

6. Run the Python script:

    ```bash
    python test-<appname>.py
    ```

### Testing the application within a Docker container

- Build a Docker image
   ```bash
   make build
   ```

- Run the application
   ```bash
   make run
   python test-<appname>
   exit
   ```

- Publish the Docker image
   ```bash
   make push
  ```

### Deploying the load generator in Kubernetes

1. Make needed changes to `ui-loadgen/heml/loadgen/values.yaml`.

2. Confirm the Chart renders the right K8S manifest files:
    ```bash
    cd ui-loadgen/heml
    helm install loadgen --dry-run --namespace nopcommerce loadgen/
    ```

3. Install the Chart:
    ```bash
    helm install loadgen --namespace nopcommerce loadgen/
    ```
**Other commands:**

- List releases:
    ```bash
    helm list --namespace <namespace>
    ```

- To delete the chart:
    ```bash
    helm uninstall loadgen --namespace nopcommerce
    ```

### nopCommerce Sample DB users

The following users come with the sample DB data, and can be user to test the application from the load generator:

Username / Password:
- james_pan@nopCommerce.com / 123456
- brenda_lindgren@nopCommerce.com	/ 123456
- steve_gates@nopCommerce.com / 123456
- arthur_holmes@nopCommerce.com / 123456

### Contributing

1. Follow the Installation steps provided above

2. Create a branch in your fork and make needed code changes

3. Make sure to document your changes on the CHANGELOG.md file

4. Submit a Pull Request


### Prerequisites

TBD


## Contributing

If there is a process for others to contribute to this tool, detail it in a CONTRIBUTING.rst file and reference it here using syntax like:

[Contribution guidelines for this project](./.github/CONTRIBUTING.rst)


## Authors

- Ovesnel Mas Lara


## License

This project is covered under the terms described in [LICENSE](./LICENSE)


## Useful Links:

- Selenium Wire: https://github.com/wkeeling/selenium-wire
- Selenium Wire on Kubernetes: https://github.com/wkeeling/selenium-wire/issues/220
