# Pull Request Template

## Description

Please include a summary of the change and which issue (defect) is fixed.
Reference any issues here, if PR closes an issue mention it like this:

FIXES #

## How Has This Been Tested?

Please describe the test that you ran to verify your changes.
You only need one option and should remove the other ones.

- [ ] Tested locally

```paste output

```

## Checklist:

- [ ] I have included the Issue in the description.
- [ ] I have referenced an issue [ⓘ](https://wwwin-github.cisco.com/E2E-Observability/SockShop-UI-loadgen/issues) in the description.
- [ ] I have added updated the `CHANGELOG.md`
- [ ] I have added the corresponding documentation in `docs` folder
- [ ] My changes generate no new warnings
- [ ] I have rebased my commits so the PR reflects as few commits as possible
- [ ] I have named my commit(s) according to what I am proposing. [ⓘ](https://wwwin-github.cisco.com/pages/AIDE/User-Guide/stable/components/core/github.html#naming-commits)
